	<?php
 	session_start();
    include_once "config.php";
	if(isset($_GET['user_id']) AND $_GET['user_id'] > 0) {
	   $getid = intval($_GET['user_id']);
	   $requser = $bdd->prepare('SELECT * FROM users WHERE user_id = ?');
	   $requser->execute(array($getid));
	   $userinfo = $requser->fetch();
	?>
	<html>
	   <head>
	      <link rel="stylesheet" type="text/css" href="style.css">
	      <meta charset="utf-8">
	   </head>
	   <body>
	      <div>
	         <h2>Profil de <?php echo $userinfo['lname']; ?></h2>
	         <br /><br />
	         <?php
	         if (!empty($userinfo['img'])){
	         ?>
	         <img src="php/images/<?php echo $userinfo['img']; ?> "width="75">
	     	 <?php }
	     	 ?><br><br>
	     	 <?php
	     	 if (isset($_SESSION['user_id'])) {?>
	     	 <br><br>
	         Nom = <?php echo $userinfo['fname']; ?>
	         <br />
	         Mail = <?php echo $userinfo['mail']; ?>
	         <br />
	         <?php
	         if(isset($_SESSION['user_id']) AND $userinfo['user_id'] == $_SESSION['user_id']) {
	         ?>
	         <br />
	         <?php
	         }
	     }
	 }
	         ?>
	      </div>
	   </body>
	</html>
	